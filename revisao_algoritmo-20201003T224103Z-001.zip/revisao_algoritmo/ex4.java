package revisao_algoritmo;

import java.util.Scanner;

public class ex4 {
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		// Fa�a um algoritmo que leia a idade de uma pessoa expressa em anos, meses e dias e
		//mostre-a expressa apenas em dias
		int id,m,dias;
		System.out.println("Digite a sua idade");
		id=scan.nextInt();
		m= id*12;
		dias= id*365;
		System.out.println("A sua idade expressa em dias �: " +dias+ " dias ");
		dias=scan.nextInt();
				
	}

}
