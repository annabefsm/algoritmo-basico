package revisao_algoritmo;

import java.util.Scanner;

public class ex9 {
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		//A f�brica de refrigerantes Meia-Cola vende seu produto em tr�s formatos: lata de 350 ml,
		//garrafa de 600 ml e garrafa de 2 litros. Se um comerciante compra uma determinada
		//quantidade de cada formato, fa�a um algoritmo para calcular quantos litros de refrigerante
		//ele comprou. O Algoritmo deve perguntar a quantidade de cada formato e ter como sa�da o
		//total em litros.
		int p,m,g; 
		double total;
		System.out.println("Digite a quantidade de lata de 350mL comprada:");
		p=scan.nextInt();
		System.out.println("Digite a quantidade de garrafas de 600mL comprada:");
		m=scan.nextInt();
		System.out.println("Digite a quantidade de garrafas de 2L comprada:" );
		g=scan.nextInt();
		total= ((p*350)/1000) + ((m*600)/1000)+ (g*2);
		System.out.println("O total comrpado em litros �: "+total+ " L ");
		total=scan.nextDouble();
		
	}
}
