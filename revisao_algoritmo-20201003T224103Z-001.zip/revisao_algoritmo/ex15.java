package revisao_algoritmo;

import java.util.Scanner;

// Fa�a um algoritmo para receber um n�mero qualquer e informar na tela se � par ou
//�mpar.

public class ex15 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		double a;
		System.out.println("Digite um n�mero qualquer");
		a=scan.nextDouble();
		if(a%2==0) {
			System.out.println("O n�mero "+a+ " � par.");
			a=scan.nextDouble();
		}else {
			System.out.println("O n�mero "+a+ " � �mpar.");
			a=scan.nextDouble();
		}
	}
}
