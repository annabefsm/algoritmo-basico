package revisao_algoritmo;

import java.util.Scanner;

public class ex10 {
	public static void main(String[]args) {
		//Marcelo recebeu seu sal�rio de R$ 1.500,00 e precisa pagar duas contas (C1= R$
		//189,00 e C2= R$ 131,00) que est�o atrasadas. Como as contas est�o atrasadas, Marcelo
		//ter� de pagar multa de 2% sobre cada conta. Fa�a um algoritmo que calcule e mostre
		//quanto restar� do sal�rio do Jo�o
		Scanner scan= new Scanner(System.in);
		double m1,m2,total;
		int c1=189, c2=131;
		m1=c1*1.2;
		m2=c2*1.2;
		total= 1500 - (m1+m2);
		System.out.println("Depois de pagar as contas restar� de sal�rio: "+total+ " reais");
		total=scan.nextDouble();	
	}
}
