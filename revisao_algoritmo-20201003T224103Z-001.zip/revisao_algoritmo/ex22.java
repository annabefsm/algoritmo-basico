package revisao_algoritmo;

import java.util.Scanner;

public class ex22 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		//Ler um n�mero do teclado e imprimir todos os n�meros de 1 at� o n�mero lido. Imprimir
		//o produto dos n�meros.
		int i= 1 ;
		double num;
		System.out.println("Digite um n�mero");
		num=scan.nextDouble();
		if(num<=100) {
			double max= num;
			while(i<= max) {
				System.out.println(i);
				i++;
			}
		}else if(num<=500) {
			double max= num;
			while(i<= max) {
				System.out.println(i);
				i++;
			}
		}else if(num<=1000) {
			double max= num;
			while(i<= max) {
				System.out.println(i);
				i++;
			}
		}
	}
}
