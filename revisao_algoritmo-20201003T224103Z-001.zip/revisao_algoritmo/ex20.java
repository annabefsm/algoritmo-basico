package revisao_algoritmo;

import java.util.Scanner;
//algoritmo incompleto, num4 a se avaliar
//Escreva um programa que receba dois n�meros inteiros e que disponibilize as op��es
//abaixo e imprima o resultado da opera��o (o usu�rio dever� o n�mero da op��o, por
//exemplo 1 se quiser somar os n�meros e assim por diante):
//1. retornar o soma de dois n�meros;
//2. retornar a subtra��o de dois n�meros;
//3. retornar a multiplica��o de dois n�meros;
//4. retornar o quociente inteiro de uma divis�o;
//5. retornar mensagem de erro (op��o inv�lida).

public class ex20 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		int a,b,op,total;
		System.out.println("Digite o primeiro valor inteiro");
		a=scan.nextInt();
		System.out.println("Digite o segundo valor inteiro");
		b=scan.nextInt();
		System.out.println("Digite o n�mero da opera��o desejada:1- soma dos dois n�meros;\r"
				+ "\n2- subtra��o dos dois n�meros; 3- multiplica��o dos dois n�meros;\r "
				+ "\n4- quociente inteiro de uma divis�o");
		op=scan.nextInt();
		if(op==1) {
			total= a+b;
			System.out.println("O valor da soma �: "+total);
			total=scan.nextInt();
		}else if(op==2) {
				total= a-b;
				System.out.println("O valor da subtra��o �: "+total);
				total=scan.nextInt();
		
		}else if(op==3) {
			total= a*b;
			System.out.println("O valor da multiplica��o �: "+total);
			total=scan.nextInt();
		}else if(op==4) {
			if(a>b) {
				total= a/b;
				System.out.println("O valor da divis�o �: "+total);
				total=scan.nextInt();
			}else {
				total= b/a;
				System.out.println("Dividindo o maior valor pelo menor encontramos: "+ total+ "."
						+ "\n Caso a opera��o desejada for o inverso: Opera��o inv�lida");
				total=scan.nextInt();
			}
			
		}else {
			System.out.println("Opera��o inv�lida");
		}
	}
}
