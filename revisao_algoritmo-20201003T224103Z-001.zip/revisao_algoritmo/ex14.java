package revisao_algoritmo;

import java.util.Scanner;

// Fa�a um algoritmo que leia os valores A, B, C e imprima na tela se a soma de A + B �
//menor que C.


public class ex14 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		double A,B,C,soma;
		System.out.println("Digite o primeiro n�mero");
		A=scan.nextDouble();
		System.out.println("Digite o segundo n�mero");
		B=scan.nextDouble();
		System.out.println("Digite o terceiro n�mero");
		C=scan.nextDouble();
		soma= A+B;
		if(soma>C) {
			System.out.println("A soma do n�mero " +A+ " com o n�mero "+B+ " "
					+ "� maior que o\n�ltimo n�mero digitado");
			A=scan.nextDouble();
			B=scan.nextDouble();
		}else if(soma<C) {
			System.out.println("A soma do n�mero " +A+ " com o n�mero "+B+ " "
					+ "� menor que o\n�ltimo n�mero digitado");
			A=scan.nextDouble();
			B=scan.nextDouble();	
		}
	}
}
