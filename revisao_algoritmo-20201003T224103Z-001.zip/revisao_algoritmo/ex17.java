package revisao_algoritmo;

import java.util.Scanner;
//duvida, no caso string
public class ex17 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		double  h,pi;
		int sexo;
		System.out.println("Se o seu sexo for feminino digite 1, caso contr�rio digite 2");
		sexo=scan.nextInt();
		System.out.println("Digite a sua altura");
		h=scan.nextDouble();
		if(sexo==1) {
			pi=(62.1*h)-44.7;
			System.out.println("O seu peso ideal �: "+pi);
			pi=scan.nextDouble();	
		}else if(sexo==2) {
			pi=(72.7*h)-58;
			System.out.println("O seu peso ideal �: "+pi+ "kg");
			pi=scan.nextDouble();	
		}else {
			System.out.println("Opera��o inv�lida");
		}	
	}
}


