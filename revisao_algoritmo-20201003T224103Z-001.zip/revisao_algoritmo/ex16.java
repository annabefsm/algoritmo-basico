package revisao_algoritmo;

import java.util.Scanner;

//Fa�a um algoritmo que leia dois valores inteiros A e B se os valores forem iguais dever�
//se somar os dois, caso contr�rio multiplique A por B. Ao final de qualquer um dos c�lculos
//deve-se atribuir o resultado para uma vari�vel C e mostrar seu conte�do na tela

public class ex16 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		int a,b,c;
		System.out.println("Digite o primeiro valor inteiro");
		a=scan.nextInt();
		System.out.println("Digite o segundo valor inteiro");
		b=scan.nextInt();
		if(a==b) {
			c=a+b;
			System.out.println("A soma dos n�meros �: "+c);
			c=scan.nextInt();	
		}else {
			c=a*b;
			System.out.println("A multiplica��o dos n�meros �: "+c);
			c=scan.nextInt();	
		}
	}
}
