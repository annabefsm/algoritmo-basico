package revisao_algoritmo;

import java.util.Scanner;

public class ex2 {
	public static void main(String [] args) {
		Scanner scan= new Scanner(System.in);
		double a,b, div;
		System.out.println("digite um n�mero");
		a=scan.nextDouble();
		System.out.println("digite um segundo n�mero");
		b=scan.nextDouble();
		if(b != 0) {
			div= a/b;
			System.out.println("o resultado da divis�o do primeiro n�mero pelo o segundo � " +div);
			div=scan.nextDouble();
		}else {
			System.out.println("opera��o inv�lida");
		}
		
	}

}
