package revisao_algoritmo;

import java.util.Scanner;

//Construa um algoritmo que dado quatro valores, A, B, C e D, o algoritmo imprima o
//maior e o menor valor

public class ex13 {
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		double A,B,C,D;
		System.out.println("Digite o primeiro n�mero");
		A=scan.nextDouble();
		System.out.println("Digite o segundo n�mero");
		B=scan.nextDouble();
		System.out.println("Digite o terceiro n�mero");
		C=scan.nextDouble();
		System.out.println("Digite o quarto n�mero");
		D=scan.nextDouble();
		if(A>B && B>C && C>D) {
			System.out.println("Ordem decrescente "+A+" - "+B+" - "+C+" - "+D);
			A=scan.nextDouble();
			B=scan.nextDouble();
			C=scan.nextDouble();
			D=scan.nextDouble();	
		}else if(A>B && B>D && D>C) {
			System.out.println("Ordem decrescente "+A+" - "+B+" - "+D+" - "+C);
			A=scan.nextDouble();
			B=scan.nextDouble();
			D=scan.nextDouble();
			C=scan.nextDouble();		
		}else if(A>C && C>B && B>D) {
			System.out.println("Ordem decrescente "+A+" - "+C+" - "+B+"  - "+D);
			A=scan.nextDouble();
			C=scan.nextDouble();
			B=scan.nextDouble();
			D=scan.nextDouble();	
		}else if(A>C && C>D && D>B) {
			System.out.println("Ordem decrescente "+A+" - "+C+" - "+D+" - "+B);
			A=scan.nextDouble();
			C=scan.nextDouble();
			D=scan.nextDouble();
			B=scan.nextDouble();	
		} else if(A>D && D>B && B>C) {
			System.out.println("Ordem decrescente "+A+" - "+D+" - "+B+" - "+C);
			A=scan.nextDouble();
			D=scan.nextDouble();
			B=scan.nextDouble();
			C=scan.nextDouble();	
		} else if(A>D && D>C && C>B) {
			System.out.println("Ordem decrescente "+A+" - "+D+" - "+C+" - "+B);
			A=scan.nextDouble();
			D=scan.nextDouble();
			C=scan.nextDouble();
			B=scan.nextDouble();	
		}else if(B>A && A>C && C>D) {
			System.out.println("Ordem decrescente "+B+" - "+A+" - "+C+" - "+D);
			B=scan.nextDouble();
			A=scan.nextDouble();
			C=scan.nextDouble();
			D=scan.nextDouble();					
		} else if(B>A && A>D && D>C) {
			System.out.println("Ordem decrescente "+B+" - "+A+" - "+D+" - "+C);
			B=scan.nextDouble();
			A=scan.nextDouble();
			D=scan.nextDouble();
			C=scan.nextDouble();					
		}else if(B>C && C>A && A>D) {
			System.out.println("Ordem decrescente "+B+"-  "+C+" - "+A+" - "+D);
			B=scan.nextDouble();
			C=scan.nextDouble();
			A=scan.nextDouble();
			D=scan.nextDouble();					
		}else if(B>C && C>D && D>A) {
			System.out.println("Ordem decrescente "+B+" - "+C+" - "+D+" - "+A);
			B=scan.nextDouble();
			C=scan.nextDouble();
			D=scan.nextDouble();
			A=scan.nextDouble();					
		}else if(B>D && D>A && A>C) {
			System.out.println("Ordem decrescente "+B+" - "+D+" - "+A+" - "+C);
			B=scan.nextDouble();
			D=scan.nextDouble();
			A=scan.nextDouble();
			C=scan.nextDouble();					
		}else if(B>D && D>C && C>A) {
			System.out.println("Ordem decrescente "+B+" - "+D+" - "+C+" - "+A);
			B=scan.nextDouble();
			D=scan.nextDouble();
			C=scan.nextDouble();
			A=scan.nextDouble();					
		}else if(C>A && A>B && B>D) {
			System.out.println("Ordem decrescente "+C+" - "+A+" - "+B+" - "+D);
			C=scan.nextDouble();
			A=scan.nextDouble();
			B=scan.nextDouble();
			D=scan.nextDouble();					
		}else if(C>A && A>D && D>B) {
			System.out.println("Ordem decrescente "+C+" - "+A+" - "+D+" - "+B);
			C=scan.nextDouble();
			A=scan.nextDouble();
			D=scan.nextDouble();
			B=scan.nextDouble();					
		}else if(C>B && B>A && A>D) {
			System.out.println("Ordem decrescente "+C+" - "+B+" - "+A+" - "+D);
			C=scan.nextDouble();
			B=scan.nextDouble();
			A=scan.nextDouble();
			D=scan.nextDouble();
		}else if(C>B && B>D && D>A) {
			System.out.println("Ordem decrescente "+C+" - "+B+" - "+D+" - "+A);
			C=scan.nextDouble();
			B=scan.nextDouble();
			D=scan.nextDouble();
			A=scan.nextDouble();
		}else if(C>D && D>B && B>A) {
			System.out.println("Ordem decrescente "+C+" - "+D+" - "+B+" - "+A);
			C=scan.nextDouble();
			D=scan.nextDouble();
			B=scan.nextDouble();
			A=scan.nextDouble();
		}else if(C>D && D>A && A>B) {
			System.out.println("Ordem decrescente "+C+"-"+D+"-"+A+"-"+B);
			C=scan.nextDouble();
			D=scan.nextDouble();
			A=scan.nextDouble();
			B=scan.nextDouble();
		}else if(D>A && A>B && B>C) {
			System.out.println("Ordem decrescente "+D+" - "+A+" - "+B+" - "+C);
			D=scan.nextDouble();
			A=scan.nextDouble();
			B=scan.nextDouble();
			C=scan.nextDouble();
		}else if(D>A && A>C && C>B) {
			System.out.println("Ordem decrescente "+D+" - "+A+" - "+C+" - "+B);
			D=scan.nextDouble();
			A=scan.nextDouble();
			C=scan.nextDouble();
			B=scan.nextDouble();
		}else if(D>B && B>A && A>C) {
			System.out.println("Ordem decrescente "+D+" - "+B+" - "+A+" - "+C);
			D=scan.nextDouble();
			B=scan.nextDouble();
			A=scan.nextDouble();
			C=scan.nextDouble();
		}else if(D>B && B>C && C>A) {
			System.out.println("Ordem decrescente "+D+" - "+B+" - "+C+" - "+A);
			D=scan.nextDouble();
			B=scan.nextDouble();
			C=scan.nextDouble();
			A=scan.nextDouble();
		}else if(D>C && C>B && B>A) {
			System.out.println("Ordem decrescente "+D+" - "+C+" - "+B+" - "+A);
			D=scan.nextDouble();
			C=scan.nextDouble();
			B=scan.nextDouble();
			A=scan.nextDouble();
		}else{
			System.out.println("Ordem decrescente "+D+" - "+C+" - "+A+" - "+B);
			D=scan.nextDouble();
			C=scan.nextDouble();
			A=scan.nextDouble();
			B=scan.nextDouble();
		}
	}
}
