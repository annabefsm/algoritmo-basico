package revisao_algoritmo;

import java.util.Scanner;

//Fa�a um programa para ler dois n�meros reais e verificar se ambos s�o maiores que
//zero. Caso positivo, informar �Valores s�o v�lidos�. Caso contr�rio, informar �Valores
//inv�lidos�.

public class ex11 {
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		int a,b;
		System.out.println("Digite um n�mero inteiro ");
		a=scan.nextInt();
		System.out.println("Digite um outro n�mero inteiro");
		b=scan.nextInt();
		if(a>0 && b>0) {
			System.out.println("Valores s�o v�lidos");
		}else {
			System.out.println("Valores inv�lidos");
		}
	}
}
