package revisao_algoritmo;

import java.util.Scanner;

public class ex6 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		//Escreva um algoritmo em JAVA que leia dois valores inteiros (A e B) e apresente o
		//resultado do quadrado da soma dos valores lidos.
		int A,B, total;
		System.out.println("Digite um n�mero inteiro:");
		A=scan.nextInt();
		System.out.println("Digite um segundo n�mero inteiro:");
		B=scan.nextInt();
		total= (A+B)*(A+B);
		System.out.println("O valor do quadrado da soma dos n�mero �: " +total);
		total=scan.nextInt();                 	
	}	
}
