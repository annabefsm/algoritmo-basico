package revisao_algoritmo;

import java.util.Scanner;
//duvida,n roda apartir do segundo if
public class ex18 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		double p1,p2,med;
		System.out.println("Digite o valor da primeira prova");
		p1=scan.nextDouble();
		System.out.println("Digite o valor da segunda prova");
		p2=scan.nextDouble();
		med=(p1*0.4)+ (p2*0.6);
		if(med>=7) {
			System.out.println("Aprovado com m�dia: "+ med);
			med=scan.nextDouble();
		}if(med<=4){
			System.out.println("Reprovado com m�dia: "+med);
			med=scan.nextDouble();
		}if(med>=4 && med<7){
			System.out.println("Em recupera��o com m�dia: "+med);
			med=scan.nextDouble();
		}
	}

}
