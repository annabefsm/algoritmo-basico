package revisao_algoritmo;

import java.util.Scanner;

public class ex25 {
	//Escrever um algoritmo que calcule e mostre a m�dia aritm�tica dos n�meros entre 12 e 98
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		int soma=0, med;
		for(int i=11; i< 98; soma+= i++);	
		System.out.println("A soma dos valores �: " +soma);
		med= soma/86;
		System.out.println("M�dia aritm�tica:" +med);
			
		
	}
}
