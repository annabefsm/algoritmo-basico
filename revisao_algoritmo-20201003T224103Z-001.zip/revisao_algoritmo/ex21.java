package revisao_algoritmo;

import java.util.Scanner;

public class ex21 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		double  salario, imp;
		String nome= null;
		System.out.println("Digite o seu nome");
		nome=scan.next();
		System.out.println("Digite o seu s�lario");
		salario=scan.nextDouble();
		if(salario<=1500) {
			System.out.println("Isento de imposto de renda");
		} else if(salario>1500 && salario<=2500) {
			imp= salario*0.15;
			System.out.println("O seu imposto de renda � de: " +imp+ " reais");
			imp=scan.nextDouble();
		} else if(salario>2500 && salario<=4000) {
			imp= salario*0.275;
			System.out.println("O seu imposto de renda � de: " +imp+ " reais");
			imp=scan.nextDouble();
		}else{
			imp= salario*0.35;
			System.out.println("O seu imposto de renda � de: " +imp+ " reais");
			imp=scan.nextDouble();
		}
		
	}
}
