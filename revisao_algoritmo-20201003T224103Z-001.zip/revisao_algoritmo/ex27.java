package revisao_algoritmo;
// duvida no ultimo item
//- Escreva um algoritmo que leia 35 valores inteiros e faça o que se pede:
//● Encontre o maior valor
//● Encontre o menor valor
//● Calcule a média aritmética dos números lidos.
//● Quantidade de números pares
//● Quantidade de números ímpares

import java.util.ArrayList;
import java.util.Collections;

import java.util.Scanner;

public class ex27 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		ArrayList<Integer> num = new ArrayList<>();
		int soma=0, med = 0,contPar = 0,contImp = 0 ;
		for(int i=0; i<5; i++) {
			System.out.println("Digite um número inteiro: ");
			
			num.add(scan.nextInt());	
		}
		int maior = Collections.max(num);
		System.out.println("o maior número digitado foi: "+maior);
		int menor = Collections.min(num);
		System.out.println("o maior número digitado foi: "+menor);
		for(int i = 0; i < 5; i++){
			soma += num.get(i);
			med = soma/5;
		}
		System.out.println("A média aritmética dos números é: " +med);
		for(int i=0; i<5; i++) {
			if(num%2==0) {
				contPar++;
			}else{
				contImp++;
			}
		}
		System.out.println("A quantidade de números pares é: " +contPar);
		System.out.println("A quantidade de números ímpares é: " +contImp);

	}
}
