package revisao_algoritmo;

import java.util.Scanner;

public class ex30 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		int n, produto = 1;
		System.out.println("Digite um n�mero: ");
		n=scan.nextInt();
		for(int i=1;i<n; i++) {
			if(n<0) {
				System.out.println("Opera��o inv�lida");
				return;
			}if(n==0 || n==1 ) {
				System.out.println("Fatorial igual a 1");
				
			}else {
				produto+= produto*i;
			}
		}
		System.out.println("O fatorial do n�mero �: "+produto);
	}
}
