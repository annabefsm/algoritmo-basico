package revisao_algoritmo;

import java.util.Scanner;

public class ex8 {
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		//Fa�a um algoritmo que calcule a quantidade de litros de combust�vel gasta em uma
		//viagem, utilizando um autom�vel que faz 12Km por litro. Para obter o c�lculo, o usu�rio deve
		//fornecer o tempo gasto na viagem e a velocidade m�dia durante ela. Desta forma, ser�
		//poss�vel obter a dist�ncia percorrida com a f�rmula DISTANCIA = TEMPO * VELOCIDADE.
		//Tendo o valor da dist�ncia, basta calcular a quantidade de litros de combust�vel utilizada na
		//viagem com a f�rmula: LITROS_USADOS = DISTANCIA / 12. O programa deve apresentar
		//os valores da velocidade m�dia, tempo gasto na viagem, a dist�ncia percorrida e a
		//quantidade de litros utilizada na viagem.
        double t,temp, vm, d, ltotal;
        System.out.println("Digite o tempo de viagem gasto em minutos:");
        temp=scan.nextDouble();
        System.out.println("Digite a velocidade m�dia da viagem:");
        vm=scan.nextDouble();
        t= temp*60;
        d=t/vm;
        ltotal= d/12;
        System.out.println("A velocidade m�dia da viagem � de: "+vm+"km/h^2 \nA dist�ncia percorrida:"
        		+ " "+d+"Km\nQuantidade de litros de gasolina gastos: "+ltotal+ "l");
        vm=scan.nextDouble();
        d=scan.nextDouble();
        ltotal=scan.nextDouble();
        		
	}
}
