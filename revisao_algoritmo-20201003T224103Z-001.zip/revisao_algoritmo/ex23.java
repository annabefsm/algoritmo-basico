package revisao_algoritmo;

import java.util.ArrayList;
import java.util.Scanner;

public class ex23 {
	public static void main(String[]args) {
		Scanner scan= new Scanner(System.in);
		// D�vida
		//Construir um algoritmo que execute o exerc�cios 5 para um n�mero indeterminado de
		//pessoas. O programa vai peguntar a matr�cula da pessoa, e enquanto for diferente de 0, vai
		//lendo as informa��es de entrada e calcula o IMC. No final, apresentar a m�dia aritm�tica do
		//IMC de todos.
		int  mat = 0, num, soma=0;
		double p=0,h = 0,ims = 0, med;
	    System.out.println("Digite o n�mero de matr�cula: " );
	    mat=scan.nextInt();
	    for(int i=0; i<mat;i++) {
	    	if(mat!=0) {
				System.out.println("Digite o n�mero de matr�cula: ");
				num=scan.nextInt();
				System.out.println("Digite  o  peso relacionado a pessoa da matr�cula: ");
				p=scan.nextDouble();
				System.out.println("Digite a altura relacionada a pessoa da matr�cula : ");
				h=scan.nextDouble();
				ims= (p)/(h*h);
				System.out.println("O seu �ndice de massa corporal � de: " +ims);
				ims=scan.nextDouble();
				while(ims<18.5) {
					System.out.println("Abaixo do peso");	
				}while(ims>=18.5 && ims<=25) {
					System.out.println("Peso normal");
				}while(ims>25 && ims<=30) {
					System.out.println("Acima do peso");
				}while(ims>30) {
					System.out.println("Obeso");
				}
				soma+= ims;
				med= soma/mat;
				System.out.println(" A m�dia aritm�tica de todos os �ndices �: " +med);
				med=scan.nextDouble();
	    	}else {
	    		System.out.println("Opera��o inv�lida");
	    	}
		}
	}
}
