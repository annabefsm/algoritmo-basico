package revisao_algoritmo;

import java.util.Scanner;

public class ex12 {
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		double peso, h, ims;
		System.out.println("Digite o seu peso");
		peso=scan.nextDouble();
		System.out.println("Digite a sua altura");
		h=scan.nextDouble();
		ims= (peso)/(h*h);
		if(ims<18.5 ) {
			System.out.println("Abaixo do peso");
		}else if(ims>=18.5 && ims<=25) {
			System.out.println("Peso normal");
		}else if(ims>25 && ims<=30) {
			System.out.println("Acima do peso");
		}else {
			System.out.println("Obeso");
		}
	}
}
