package revisao_algoritmo;

import java.util.Scanner;

public class ex7 {
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		//Fa�a um algoritmo que leia uma temperatura em graus Celsius e apresente-a convertida
		//em graus Fahrenheit. A f�rmula de convers�o �: F = (9 * C + 160) / 5, na qual F � a
		//temperatura em Fahrenheit e C � a temperatura em Celsius;
		double temp,F;
		System.out.println("Digite o valor da temperatura em graus Celsius");
		temp=scan.nextDouble();
		if(temp>150) {
			System.out.println("Opera��o invalida");
		}else {
		F=((9*temp) + 160)/5;
		System.out.println("O valor da temperatura convertida de graus Celsius\npara Fahrenheit �: "+F+ " F");
		F=scan.nextDouble();	
		}
	}

}
