package revisao_algoritmo;

import java.util.Scanner;

public class ex5 {
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in );
		//A padaria P�O vende uma certa quantidade de p�es franceses e uma quantidade de
		//broas a cada dia. Cada p�ozinho custa R$ 0,33 e a broa custa R$ 0,87. Ao final do dia, o
		//dono quer saber quanto arrecadou com a venda dos p�es e broas (juntos), e quanto deve
		//guardar numa conta de poupan�a (10% do total arrecadado). Voc� foi contratado para fazer
		//os c�lculos para o dono. Com base nestes fatos, fa�a um algoritmo para ler as quantidades
		//de p�es e de broas, e depois calcular os dados solicitados.
		int p,b;
		double total,poup;
	    System.out.println("Digite o total de p�es vendidos no dia:");
	    p=scan.nextInt();
	    System.out.println("Digite o total de broas vendidas no dia:");
	    b=scan.nextInt();
	    total= (p*0.33) + (b*0.87);
	    poup= 0.1* total;
	    System.out.println("O total arrecadado com a venda de p�es e broas no dia foi: "+total+ " reais"
	    		+ "\nO valor que precisa ser guardado em poupan�a � de:" +poup+" reais");
	    total=scan.nextDouble();
	    poup=scan.nextDouble();
		
	}

}
